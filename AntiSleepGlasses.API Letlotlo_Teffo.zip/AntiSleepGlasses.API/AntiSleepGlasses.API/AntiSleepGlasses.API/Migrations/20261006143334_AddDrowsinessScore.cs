﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AntiSleepGlasses.API_.Migrations
{
    /// <inheritdoc />
    public partial class AddDrowsinessScore : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "DrowsinessScore",
                table: "DrowsinessEvents",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DrowsinessScore",
                table: "DrowsinessEvents");
        }
    }
}
